import { Component } from "react"
import Header from "./Header"

export default class HomeRoutes extends Component{
render(){
    return(
        <Header/> 
    );
}
   
}